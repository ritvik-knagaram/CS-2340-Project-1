package com.example.classscheduler;

public class Classes {

    String name, professor, section, roomNum, location, days, time;

    public Classes(String name, String professor, String location, String section, String roomNum, String days, String time) {
        this.name = name;
        this.professor = professor;
        this.section = section;
        this.roomNum = roomNum;
        this.location = location;
        this.days = days;
        this.time = time;
    }
}
