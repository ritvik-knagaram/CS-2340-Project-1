package com.example.classscheduler;

public class Assignments {
    String dueDate, assignmentClass, Incomplete, assignmentName;

    public Assignments (String dueDate, String assignmentClass, String Incomplete, String assignmentName) {
        this.dueDate = dueDate;
        this.assignmentClass = assignmentClass;
        this.assignmentName = assignmentName;
        this.Incomplete = Incomplete;
    }
}
