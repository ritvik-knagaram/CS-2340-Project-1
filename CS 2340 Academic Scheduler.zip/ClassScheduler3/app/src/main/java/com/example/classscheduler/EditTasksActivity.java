package com.example.classscheduler;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditTasksActivity extends AppCompatActivity {

    EditText assignmentNameInput;
    EditText assignmentClassNameInput;
    EditText dueDateInput;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_tasks);

        int editIndex = getIntent().getExtras().getInt("edit");
        String[][] taskArr = (String[][]) getIntent().getExtras().getSerializable("taskArr");
        int curr = getIntent().getExtras().getInt("curr");

        assignmentNameInput = (EditText) findViewById(R.id.assignmentName);
        assignmentClassNameInput = (EditText) findViewById(R.id.className);
        dueDateInput = (EditText) findViewById(R.id.dueDate);

        Button submitBtn = (Button) findViewById(R.id.addSubmit);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(EditTasksActivity.this)
                        .setIcon(android.R.drawable.ic_menu_edit)
                        .setTitle("Are you sure?")
                        .setMessage("Do you want to confirm your edits for this task?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                taskArr[editIndex][0] = editData(assignmentNameInput.getText().toString(),taskArr,editIndex,0);
                                taskArr[editIndex][1] = editData(assignmentClassNameInput.getText().toString(),taskArr,editIndex,1);
                                taskArr[editIndex][2] = editData(dueDateInput.getText().toString(), taskArr, editIndex, 2);

                                Intent j = new Intent(EditTasksActivity.this, TodoActivity.class);
                                Bundle bundle = new Bundle();
                                bundle.putSerializable("taskArr", taskArr);
                                bundle.putInt("curr",curr);
                                j.putExtras(bundle);
                                startActivity(j);
                                ((Activity) EditTasksActivity.this).overridePendingTransition(0,0);
                            }
                        })
                        .setNegativeButton("No",null).show();
            }
        });

    }

    public String editData(String s, String[][] arr, int index, int num) {
        if (s.isEmpty()) {
            return arr[index][num];
        }  else {
            return s;
        }
    }
}