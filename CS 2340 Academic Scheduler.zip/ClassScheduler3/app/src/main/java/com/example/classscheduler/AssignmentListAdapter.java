package com.example.classscheduler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

import kotlinx.coroutines.Incomplete;

public class AssignmentListAdapter extends ArrayAdapter<Assignments> {
    public AssignmentListAdapter(Context context, ArrayList<Assignments> assignmentArrayList){
        super(context,R.layout.tasks_layout,assignmentArrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Assignments assignments = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.tasks_layout,parent,false);
        }

        TextView dueDate = convertView.findViewById(R.id.dueDate);
        TextView assignmentName = convertView.findViewById(R.id.assignmentName);
        TextView assignmentClass = convertView.findViewById(R.id.assignmentClass);
        TextView completion = convertView.findViewById(R.id.completion);

        if (assignments.dueDate.isEmpty()) {
            dueDate.setText("0000-00-00");
        } else {
            dueDate.setText(assignments.dueDate);
        }
        if (assignments.assignmentClass.isEmpty()) {
            assignmentClass.setText("Class");
        } else {
            assignmentClass.setText(assignments.assignmentClass);
        }
        if (assignments.assignmentName.isEmpty()) {
            assignmentName.setText("Assignment");
        } else {
            assignmentName.setText(assignments.assignmentName);
        }

        if (assignments.Incomplete.equals("a")) {
            completion.setText("Incomplete");
        } else {
            completion.setText("Complete");
        }

        return convertView;
    }

}
