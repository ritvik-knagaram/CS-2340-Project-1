package com.example.classscheduler;


import static android.content.Intent.getIntent;
import static android.content.Intent.getIntentOld;
import static android.content.Intent.parseUri;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.navigation.fragment.NavHostFragment;

import com.example.classscheduler.databinding.ActivityTodoBinding;
import com.example.classscheduler.databinding.FragmentFirstBinding;

import java.util.ArrayList;


public class FirstFragment extends BaseFragment {
    private FragmentFirstBinding binding;

    int curr2 = 0;
    String[][] taskArr = new String[curr][4];


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getActivity().getIntent().hasExtra("taskArr")) {
            taskArr = (String[][]) getActivity().getIntent().getExtras().getSerializable("taskArr");
            curr2 = getActivity().getIntent().getExtras().getInt("curr");
        }

        ArrayList<Classes> classesArrayList = new ArrayList<>();
        if (class_data.length != 0) {
            for (int i = 0; i < curr; i++) {
                Classes classes = new Classes(class_data[i][0], class_data[i][1], class_data[i][2], class_data[i][3], class_data[i][4], class_data[i][5], class_data[i][6]);
                classesArrayList.add(classes);
            }
        }


        ClassListAdapter classListAdapter = new ClassListAdapter(getContext(), classesArrayList);
        binding.classListView.setAdapter(classListAdapter);


        binding.classListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final int which_item = position;
                PopupMenu editclassesPopup = new PopupMenu(getContext(), view);
                editclassesPopup.getMenuInflater().inflate(R.menu.edit_classes_popup, editclassesPopup.getMenu());
                editclassesPopup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getTitle().equals("Remove Class")) {
                            new AlertDialog.Builder(getContext())
                                    .setIcon(android.R.drawable.ic_delete)
                                    .setTitle("Are you sure?")
                                    .setMessage("Do you want to delete this class?")
                                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            classesArrayList.remove(which_item);
                                            classListAdapter.notifyDataSetChanged();
                                            curr--;
                                            class_data = remove(which_item, class_data);
                                        }
                                    })
                                    .setNegativeButton("No",null).show();

                            return true;
                        }
                        if (item.getTitle().equals("Edit Class")) {
                            editIndex = which_item;
                            NavHostFragment.findNavController(FirstFragment.this)
                                    .navigate(R.id.action_Classes_to_EditClasses);
                        }
                        return true;
                    }
                });
                editclassesPopup.show();
                return true;
            }
        });


        Button button = (Button) getView().findViewById(R.id.sortClasses);

        binding.addClasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_Classes_to_addClasses);
            }
        });

        binding.navCalendarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), CalendarMainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("taskArr", taskArr);
                bundle.putInt("curr", curr2);
                i.putExtras(bundle);
                startActivity(i);
                ((Activity) getActivity()).overridePendingTransition(0, 0);
            }
        });

        binding.navTodoList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                Intent i = new Intent(getActivity(), TodoActivity.class);
                bundle.putSerializable("taskArr", taskArr);
                bundle.putInt("curr", curr2);
                i.putExtras(bundle);
                startActivity(i);
                ((Activity) getActivity()).overridePendingTransition(0,0);
            }
        });
    }

    public String[][] remove(int index, String[][] arr) {
        String[][] temp = new String[curr][7];
        for (int i = 0; i < index; i++) {
            temp[i] = arr[i];
        }
        for (int i = index; i < curr; i++) {
            temp[i] = arr[i+1];
        }
        return temp;
    }


        @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}