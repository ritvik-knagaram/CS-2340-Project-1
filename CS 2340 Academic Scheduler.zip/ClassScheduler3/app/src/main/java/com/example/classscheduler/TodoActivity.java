package com.example.classscheduler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class TodoActivity extends AppCompatActivity {
    int curr = 0;
    String[][] taskArr = new String[curr][4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);

        if (getIntent().hasExtra("taskArr")) {
            taskArr = (String[][]) getIntent().getExtras().getSerializable("taskArr");
            curr = getIntent().getExtras().getInt("curr");
        }

        ArrayList<Assignments> assignmentsArrayList = new ArrayList<>();
        if (curr != 0) {
            for (int i = 0; i < curr; i++) {
                Assignments assignments = new Assignments(taskArr[i][2],taskArr[i][1],taskArr[i][3], taskArr[i][0]);
                assignmentsArrayList.add(assignments);
            }
        }

        AssignmentListAdapter assignmentListAdapter = new AssignmentListAdapter(getApplicationContext(), assignmentsArrayList);
        ListView assignmentListView = (ListView) findViewById(R.id.assignmentListView);
        assignmentListView.setAdapter(assignmentListAdapter);

        Button sortBtn = (Button) findViewById(R.id.sortClasses);

        sortBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu sortPopupMenu = new PopupMenu(getApplicationContext(),sortBtn);
                sortPopupMenu.getMenuInflater().inflate(R.menu.sort_tasks_popup, sortPopupMenu.getMenu());
                sortPopupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getTitle().equals("Class")) {
                            Collections.sort(assignmentsArrayList, new Comparator<Assignments>() {
                                @Override
                                public int compare(Assignments o1, Assignments o2) {
                                    return o1.assignmentClass.compareToIgnoreCase(o2.assignmentClass);
                                }
                            });
                            assignmentListAdapter.notifyDataSetChanged();
                        }
                        if (item.getTitle().equals("Incomplete")) {
                            assignmentsArrayList.clear();
                            for (int i = 0; i < curr; i++) {
                                Assignments assignments = new Assignments(taskArr[i][2],taskArr[i][1],taskArr[i][3], taskArr[i][0]);
                                assignmentsArrayList.add(assignments);
                            }
                            Collections.sort(assignmentsArrayList, new Comparator<Assignments>() {
                                @Override
                                public int compare(Assignments o1, Assignments o2) {
                                    return  o1.Incomplete.compareToIgnoreCase(o2.Incomplete);
                                }
                            });
                            assignmentListAdapter.notifyDataSetChanged();

                        }
                        if (item.getTitle().equals("Date")) {
                            Collections.sort(assignmentsArrayList, new Comparator<Assignments>() {
                                DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
                                @Override
                                public int compare(Assignments o1, Assignments o2) {
                                    try {
                                        return df.parse(o1.dueDate).compareTo(df.parse(o2.dueDate));
                                    } catch (ParseException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                            });
                            assignmentListAdapter.notifyDataSetChanged();
                        }
                        return false;
                    }
                });
                sortPopupMenu.show();
            }
        });

        assignmentListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final int which_item = position;
                PopupMenu edittasksPopup = new PopupMenu(TodoActivity.this, view);
                edittasksPopup.getMenuInflater().inflate(R.menu.edit_tasks_popup, edittasksPopup.getMenu());
                edittasksPopup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getTitle().equals("Remove Task")) {
                            new AlertDialog.Builder(TodoActivity.this)
                                    .setIcon(android.R.drawable.ic_delete)
                                    .setTitle("Are you sure?")
                                    .setMessage("Do you want to delete this task?")
                                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            assignmentsArrayList.remove(which_item);
                                            assignmentListAdapter.notifyDataSetChanged();
                                            curr--;
                                            taskArr = remove(which_item, taskArr);
                                        }
                                    })
                                    .setNegativeButton("No",null).show();

                            return true;
                        }
                        if (item.getTitle().equals("Edit Task")) {
                            Bundle bundle = new Bundle();
                            bundle.putSerializable("taskArr",taskArr);
                            bundle.putInt("edit",which_item);
                            bundle.putInt("curr",curr);
                            Intent i = new Intent(TodoActivity.this, EditTasksActivity.class);
                            i.putExtras(bundle);
                            startActivity(i);
                            ((Activity) TodoActivity.this).overridePendingTransition(0, 0);
                        }
                        if (item.getTitle().equals("Complete/Incomplete")) {
                            if (taskArr[which_item][3].equals("a")) {
                                taskArr[which_item][3] = "b";
                            } else {
                                taskArr[which_item][3] = "a";
                            }
                            assignmentsArrayList.clear();
                            for (int i = 0; i < curr; i++) {
                                Assignments assignments = new Assignments(taskArr[i][2],taskArr[i][1],taskArr[i][3], taskArr[i][0]);
                                assignmentsArrayList.add(assignments);
                            }
                            assignmentListAdapter.notifyDataSetChanged();
                        }
                        return true;
                    }
                });
                edittasksPopup.show();
                return true;
            }
        });

        Button navCalendarBtn = (Button) findViewById(R.id.navCalendarBtn);

        navCalendarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TodoActivity.this, CalendarMainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("taskArr",taskArr);
                bundle.putInt("curr",curr);
                i.putExtras(bundle);
                startActivity(i);
                ((Activity) TodoActivity.this).overridePendingTransition(0, 0);
            }
        });

        Button navClassBtn = (Button) findViewById(R.id.navClasses);
        navClassBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TodoActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("taskArr",taskArr);
                bundle.putInt("curr",curr);
                i.putExtras(bundle);
                startActivity(i);
                ((Activity) TodoActivity.this).overridePendingTransition(0,0);
            }
        });

        Button addTask = (Button) findViewById(R.id.addTask);
        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TodoActivity.this, AddTasks.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("taskArr",taskArr);
                bundle.putInt("curr",curr);
                i.putExtras(bundle);
                startActivity(i);
                ((Activity) TodoActivity.this).overridePendingTransition(0,0);
            }
        });
    }

    public String[][] remove(int index, String[][] arr) {
        String[][] temp = new String[curr][7];
        for (int i = 0; i < index; i++) {
            temp[i] = arr[i];
        }
        for (int i = index; i < curr; i++) {
            temp[i] = arr[i+1];
        }
        return temp;
    }

}