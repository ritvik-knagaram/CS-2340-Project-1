package com.example.classscheduler;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class AddTasks extends AppCompatActivity {

    EditText assignmentNameInput;
    EditText assignmentClassNameInput;
    EditText dueDateInput;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_tasks);

        assignmentNameInput = (EditText) findViewById(R.id.assignmentName);
        assignmentClassNameInput = (EditText) findViewById(R.id.className);
        dueDateInput = (EditText) findViewById(R.id.dueDate);


        Button submitBtn = (Button) findViewById(R.id.addSubmit);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int curr = getIntent().getExtras().getInt("curr");
                String[][] taskArr = (String[][]) getIntent().getExtras().getSerializable("taskArr");

                curr++;

                taskArr = expandArr(curr, taskArr);
                taskArr[curr - 1][0] = assignmentNameInput.getText().toString();
                taskArr[curr-1][1] = assignmentClassNameInput.getText().toString();
                taskArr[curr-1][2] = dueDateInput.getText().toString();
                taskArr[curr-1][3] = "a";

                Intent j = new Intent(AddTasks.this, TodoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putInt("curr",curr);
                bundle.putSerializable("taskArr", taskArr);
                j.putExtras(bundle);
                startActivity(j);
                ((Activity) AddTasks.this).overridePendingTransition(0,0);
            }
        });
    }
    public static String[][] expandArr(int curr, String[][] arr){
        System.out.println(curr);
        String[][] temp = new String[curr][7];
        for (int i = 0; i < curr - 1; i++) {
            temp[i] = arr[i];
        }
        return temp;
    }
}