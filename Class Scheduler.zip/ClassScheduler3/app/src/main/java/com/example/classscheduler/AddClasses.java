package com.example.classscheduler;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.classscheduler.databinding.FragmentAddClassesBinding;


public class AddClasses extends BaseFragment {

    EditText classNameInput;
    EditText professorNameInput;
    EditText locationInput;
    EditText classSectionInput;
    EditText roomNumInput;
    EditText timeInput;
    EditText daysInput;

    Button submitButton;

    @Override
    public void onCreate(Bundle SavedInstanceState){
        super.onCreate(SavedInstanceState);

    }

    private @NonNull FragmentAddClassesBinding binding;
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentAddClassesBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        classNameInput = (EditText) getView().findViewById(R.id.className);
        professorNameInput = (EditText) getView().findViewById(R.id.classProfessor);
        locationInput = (EditText) getView().findViewById(R.id.classLocation);
        classSectionInput = (EditText) getView().findViewById(R.id.classSection);
        roomNumInput = (EditText) getView().findViewById(R.id.roomNum);
        daysInput = (EditText) getView().findViewById(R.id.classDays);
        timeInput = (EditText) getView().findViewById(R.id.classTime);
        submitButton = (Button) getView().findViewById(R.id.addSubmit);

        binding.addSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                curr++;
                class_data = expandArr(curr, class_data);
                class_data[curr - 1][0] = classNameInput.getText().toString();
                class_data[curr - 1][1] = professorNameInput.getText().toString();
                class_data[curr - 1][2] = locationInput.getText().toString();
                class_data[curr - 1][3] = classSectionInput.getText().toString();
                class_data[curr - 1][4] = roomNumInput.getText().toString();
                class_data[curr - 1][5] = daysInput.getText().toString();
                class_data[curr - 1][6] = timeInput.getText().toString();

                NavHostFragment.findNavController(AddClasses.this)
                    .navigate(R.id.action_addClasses_to_Classes);
            }
        });
    }

    public static String[][] expandArr(int curr, String[][] arr){
        System.out.println(curr);
        String[][] temp = new String[curr][7];
        for (int i = 0; i < curr - 1; i++) {
            temp[i] = arr[i];
        }
        return temp;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}