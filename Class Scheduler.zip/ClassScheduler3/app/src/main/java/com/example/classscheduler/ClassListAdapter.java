package com.example.classscheduler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ClassListAdapter extends ArrayAdapter<Classes> {
    public ClassListAdapter(Context context, ArrayList<Classes> classArrayList){
        super(context,R.layout.list_classes,classArrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Classes classes = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_classes,parent,false);
        }

        TextView className = convertView.findViewById(R.id.classNameList);
        TextView professorName = convertView.findViewById(R.id.classProfessorList);
        TextView classLocation = convertView.findViewById(R.id.classLocationList);
        TextView roomNum = convertView.findViewById(R.id.roomNum);
        TextView section = convertView.findViewById(R.id.classSectionList);
        TextView days = convertView.findViewById(R.id.days);
        TextView time = convertView.findViewById(R.id.timeList);

        if (classes.name.isEmpty()) {
            className.setText("Class");
        } else {
            className.setText(classes.name);
        }
        if (classes.professor.isEmpty()) {
            professorName.setText("Professor");
        } else {
            professorName.setText(classes.professor);
        }
        if (classes.location.isEmpty()) {
            classLocation.setText("Location");
        } else {
            classLocation.setText(classes.location);
        }
        if (classes.roomNum.isEmpty()) {
            roomNum.setText("Room Num");
        } else {
            roomNum.setText(classes.roomNum);
        }
        if (classes.section.isEmpty()) {
            section.setText("Section");
        } else {
            section.setText(classes.section);
        }
        if (classes.days.isEmpty()) {
            days.setText("Days");
        } else {
            days.setText(classes.days);
        }
        if (classes.time.isEmpty()) {
            time.setText("Time");
        } else {
            time.setText(classes.time);
        }

        return convertView;
    }

}
