package com.example.classscheduler;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.classscheduler.databinding.FragmentAddClassesBinding;


public class EditClasses extends BaseFragment {

    EditText classNameInput;
    EditText professorNameInput;
    EditText locationInput;
    EditText classSectionInput;
    EditText roomNumInput;
    EditText timeInput;
    EditText daysInput;

    Button submitButton;

    @Override
    public void onCreate(Bundle SavedInstanceState){
        super.onCreate(SavedInstanceState);

    }

    private @NonNull FragmentAddClassesBinding binding;
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentAddClassesBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        classNameInput = (EditText) getView().findViewById(R.id.className);
        professorNameInput = (EditText) getView().findViewById(R.id.classProfessor);
        locationInput = (EditText) getView().findViewById(R.id.classLocation);
        classSectionInput = (EditText) getView().findViewById(R.id.classSection);
        roomNumInput = (EditText) getView().findViewById(R.id.roomNum);
        daysInput = (EditText) getView().findViewById(R.id.classDays);
        timeInput = (EditText) getView().findViewById(R.id.classTime);
        submitButton = (Button) getView().findViewById(R.id.addSubmit);

        binding.addSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    new AlertDialog.Builder(getContext())
                            .setIcon(android.R.drawable.ic_menu_edit)
                            .setTitle("Are you sure?")
                            .setMessage("Do you want to confirm your edits for this class?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    class_data[editIndex][0] = editData(classNameInput.getText().toString(),class_data,editIndex,0);
                                    class_data[editIndex][1] = editData(professorNameInput.getText().toString(),class_data,editIndex,1);
                                    class_data[editIndex][2] = editData(locationInput.getText().toString(),class_data,editIndex,2);
                                    class_data[editIndex][3] = editData(classSectionInput.getText().toString(),class_data,editIndex,3);
                                    class_data[editIndex][4] = editData(roomNumInput.getText().toString(),class_data,editIndex,4);
                                    class_data[editIndex][5] = editData(daysInput.getText().toString(),class_data,editIndex,5);
                                    class_data[editIndex][6] = editData(timeInput.getText().toString(),class_data,editIndex,6);

                                    NavHostFragment.findNavController(EditClasses.this)
                                            .navigate(R.id.action_EditClasses_to_Classes);
                                }
                            })
                            .setNegativeButton("No",null).show();
            }
        });
    }

    public String editData(String s, String[][] arr, int index, int num) {
        if (s.isEmpty()) {
           return arr[index][num];
        }  else {
            return s;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}