package com.example.classscheduler;

import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class BaseFragment extends Fragment {

    static int curr = 0;
    static int editIndex;
    static String[][] class_data = new String[curr][7];


}
